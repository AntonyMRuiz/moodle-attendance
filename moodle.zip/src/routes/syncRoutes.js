import express from 'express';
import { authRequired, requireAdmin } from '../middlewares/auth.js';
import {
  syncAllAttendanceConfigs,
  syncAttendanceForConfig
} from '../services/attendanceService.js';
import { AttendanceConfig } from '../models/index.js';

export const syncRouter = express.Router();

/**
 * Sincronizar TODO lo configurado en attendance_configs
 * POST /sync/attendance/all
 */
syncRouter.post('/attendance/all', authRequired, requireAdmin, async (req, res) => {
  try {
    await syncAllAttendanceConfigs();
    res.json({ message: 'Sincronización masiva completada' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error en sync masivo' });
  }
});

/**
 * Sincronizar una sola config por id (útil para pruebas)
 * POST /sync/attendance/:configId
 */
syncRouter.post('/attendance/:configId', authRequired, requireAdmin, async (req, res) => {
  try {
    const { configId } = req.params;
    const cfg = await AttendanceConfig.findByPk(configId);
    if (!cfg) {
      return res.status(404).json({ error: 'Config no encontrada' });
    }
    await syncAttendanceForConfig(cfg);
    res.json({ message: `Sincronización completada para config ${configId}` });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error sincronizando config' });
  }
});
