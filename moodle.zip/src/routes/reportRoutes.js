import express from 'express';
import { authRequired } from '../middlewares/auth.js';
import {
  getWeeklyReportByGroup,
  getMonthlySummaryByGroup
} from '../services/attendanceService.js';

export const reportRouter = express.Router();

/**
 * GET /reports/weekly?groupId=742&start=2025-11-10&end=2025-11-16
 */
reportRouter.get('/weekly', authRequired, async (req, res) => {
  try {
    const { groupId, start, end } = req.query;
    if (!groupId || !start || !end) {
      return res.status(400).json({ error: 'groupId, start y end son requeridos' });
    }

    const data = await getWeeklyReportByGroup(groupId, start, end);
    res.json(data);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error obteniendo reporte semanal' });
  }
});

/**
 * GET /reports/monthly?groupId=742&start=2025-11-01&end=2025-11-30
 */
reportRouter.get('/monthly', authRequired, async (req, res) => {
  try {
    const { groupId, start, end } = req.query;
    if (!groupId || !start || !end) {
      return res.status(400).json({ error: 'groupId, start y end son requeridos' });
    }

    const data = await getMonthlySummaryByGroup(groupId, start, end);
    res.json(data);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error obteniendo reporte mensual' });
  }
});
