import express from 'express';
import { authRequired } from '../middlewares/auth.js';
import { Campus, Cohort, Clan, Course, Group } from '../models/index.js';

export const metaRouter = express.Router();

metaRouter.get('/campuses', authRequired, async (req, res) => {
  const campuses = await Campus.findAll();
  res.json(campuses);
});

metaRouter.get('/cohorts', authRequired, async (req, res) => {
  const { campusId } = req.query;
  const where = campusId ? { campusId } : {};
  const cohorts = await Cohort.findAll({ where });
  res.json(cohorts);
});

metaRouter.get('/clans', authRequired, async (req, res) => {
  const { cohortId } = req.query;
  const where = cohortId ? { cohortId } : {};
  const clans = await Clan.findAll({ where });
  res.json(clans);
});

metaRouter.get('/courses', authRequired, async (req, res) => {
  const { cohortId } = req.query;
  const where = cohortId ? { cohortId } : {};
  const courses = await Course.findAll({ where });
  res.json(courses);
});

metaRouter.get('/groups', authRequired, async (req, res) => {
  const { courseId } = req.query;
  const where = courseId ? { courseId } : {};
  const groups = await Group.findAll({ where });
  res.json(groups);
});
