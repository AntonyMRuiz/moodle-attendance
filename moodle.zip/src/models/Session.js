import { DataTypes, Model } from 'sequelize';

export class Session extends Model {}

export function initSession(sequelize) {
  Session.init(
    {
      id: { type: DataTypes.BIGINT, autoIncrement: true, primaryKey: true },

      // IDs Moodle
      moodleSessionId: { type: DataTypes.BIGINT, allowNull: false, unique: true },
      attendanceid: { type: DataTypes.BIGINT, allowNull: false },
      courseId: { type: DataTypes.BIGINT, allowNull: true }, // courseid Moodle
      groupId: { type: DataTypes.BIGINT, allowNull: true },  // groupid Moodle

      // vínculo a la config
      attendanceConfigId: {
        type: DataTypes.BIGINT,
        allowNull: false
      },

      // contexto RIWI
      cohortId: { type: DataTypes.BIGINT, allowNull: false },
      clanId: { type: DataTypes.BIGINT, allowNull: true },

      // info de la sesión
      sessdate: { type: DataTypes.DATE, allowNull: false },
      description: { type: DataTypes.STRING(255) },
      duration: { type: DataTypes.INTEGER },

      moodleUrl: { type: DataTypes.STRING(512) },

      // resumen de asistencia
      totalStudents: { type: DataTypes.INTEGER, defaultValue: 0 },
      presentCount: { type: DataTypes.INTEGER, defaultValue: 0 },     // P
      lateCount: { type: DataTypes.INTEGER, defaultValue: 0 },        // R
      justifiedCount: { type: DataTypes.INTEGER, defaultValue: 0 },   // FJ
      unjustifiedCount: { type: DataTypes.INTEGER, defaultValue: 0 }  // FI
    },
    {
      sequelize,
      modelName: 'Session',
      tableName: 'sessions',
      timestamps: true
    }
  );
}
