import { DataTypes, Model } from 'sequelize';

export class AttendanceConfig extends Model {}

export function initAttendanceConfig(sequelize) {
  AttendanceConfig.init(
    {
      id: {
        type: DataTypes.BIGINT,
        autoIncrement: true,
        primaryKey: true
      },
      // Cohorte y clan (nuestros conceptos)
      cohortId: {
        type: DataTypes.BIGINT,
        allowNull: false
      },
      clanId: {
        type: DataTypes.BIGINT,
        allowNull: true
      },
      // Turno
      shift: {
        type: DataTypes.ENUM('AM', 'PM'),
        allowNull: false
      },
      // Identificadores de Moodle
      moodleAttendanceId: {
        type: DataTypes.BIGINT,
        allowNull: false
      },
      moodleGroupId: {
        // 0 = general sin grupo; >0 = grupo/clan específico
        type: DataTypes.BIGINT,
        allowNull: false,
        defaultValue: 0
      },
      moodleCourseId: {
        type: DataTypes.BIGINT,
        allowNull: true
      },
      // Texto amigable para mostrar
      label: {
        type: DataTypes.STRING(150),
        allowNull: false
      },
      enabled: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true
      }
    },
    {
      sequelize,
      modelName: 'AttendanceConfig',
      tableName: 'attendance_configs',
      timestamps: false
    }
  );
}
