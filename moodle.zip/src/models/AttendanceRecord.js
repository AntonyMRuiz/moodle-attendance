import { DataTypes, Model } from 'sequelize';

export class AttendanceRecord extends Model {}

export function initAttendanceRecord(sequelize) {
  AttendanceRecord.init(
    {
      id: { type: DataTypes.BIGINT, autoIncrement: true, primaryKey: true },
      statusAcronym: { type: DataTypes.STRING(10), allowNull: false }, // P/R/FJ/FI
      statusDescription: { type: DataTypes.STRING(100) },
      statusGrade: { type: DataTypes.INTEGER },
      remarks: { type: DataTypes.STRING(255) }
    },
    {
      sequelize,
      modelName: 'AttendanceRecord',
      tableName: 'attendance_records',
      timestamps: true
    }
  );
}
