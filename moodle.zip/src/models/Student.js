import { DataTypes, Model } from 'sequelize';

export class Student extends Model {}

export function initStudent(sequelize) {
  Student.init(
    {
      moodleUserId: { type: DataTypes.BIGINT, primaryKey: true },
      firstname: { type: DataTypes.STRING(100) },
      lastname: { type: DataTypes.STRING(100) },
      fullname: { type: DataTypes.STRING(201) }
    },
    {
      sequelize,
      modelName: 'Student',
      tableName: 'students',
      timestamps: false
    }
  );
}
