import { DataTypes, Model } from 'sequelize';

export class Group extends Model {}

export function initGroup(sequelize) {
  Group.init(
    {
      id: { type: DataTypes.BIGINT, autoIncrement: true, primaryKey: true },
      moodleGroupId: { type: DataTypes.BIGINT, allowNull: false, unique: true },
      name: { type: DataTypes.STRING(150) }
    },
    {
      sequelize,
      modelName: 'Group',
      tableName: 'groups',
      timestamps: false
    }
  );
}
