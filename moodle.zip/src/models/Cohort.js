import { DataTypes, Model } from 'sequelize';

export class Cohort extends Model {}

export function initCohort(sequelize) {
  Cohort.init(
    {
      id: { type: DataTypes.BIGINT, autoIncrement: true, primaryKey: true },
      name: { type: DataTypes.STRING(150), allowNull: false, unique: true },
      startDate: { type: DataTypes.DATEONLY },
      endDate: { type: DataTypes.DATEONLY }
    },
    {
      sequelize,
      modelName: 'Cohort',
      tableName: 'cohorts',
      timestamps: false
    }
  );
}
