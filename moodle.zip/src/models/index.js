import { sequelize } from "../config/db.js";
import { initUser, User } from "./User.js";
import { initCampus, Campus } from "./Campus.js";
import { initCohort, Cohort } from "./Cohort.js";
import { initClan, Clan } from "./Clan.js";
import { initCourse, Course } from "./Course.js";
import { initGroup, Group } from "./Group.js";
import { initStudent, Student } from "./Student.js";
import { initSession, Session } from "./Session.js";
import { initAttendanceRecord, AttendanceRecord } from "./AttendanceRecord.js";
import { initAttendanceConfig, AttendanceConfig } from "./AttendanceConfig.js";
import { initStudentCohort, StudentCohort } from "./StudentCohort.js";
import { initAdminUser } from "./AdminUser.js";

export function initModels() {
  initUser(sequelize);
  initCampus(sequelize);
  initCohort(sequelize);
  initClan(sequelize);
  initCourse(sequelize);
  initGroup(sequelize);
  initStudent(sequelize);
  initSession(sequelize);
  initAttendanceRecord(sequelize);
  initAttendanceConfig(sequelize);
  initStudentCohort(sequelize);
  initAdminUser(sequelize);

  // Campus 1-N Cohort
  Campus.hasMany(Cohort, { foreignKey: "campusId" });
  Cohort.belongsTo(Campus, { foreignKey: "campusId" });

  // Cohort 1-N Clan
  Cohort.hasMany(Clan, { foreignKey: "cohortId" });
  Clan.belongsTo(Cohort, { foreignKey: "cohortId" });

  // Cohort 1-N AttendanceConfig
  Cohort.hasMany(AttendanceConfig, { foreignKey: "cohortId" });
  AttendanceConfig.belongsTo(Cohort, { foreignKey: "cohortId" });

  // Clan 1-N AttendanceConfig
  Clan.hasMany(AttendanceConfig, { foreignKey: "clanId" });
  AttendanceConfig.belongsTo(Clan, { foreignKey: "clanId" });

  // AttendanceConfig 1-N Session
  AttendanceConfig.hasMany(Session, { foreignKey: "attendanceConfigId" });
  Session.belongsTo(AttendanceConfig, { foreignKey: "attendanceConfigId" });

  // Cohort 1-N Session
  Cohort.hasMany(Session, { foreignKey: "cohortId" });
  Session.belongsTo(Cohort, { foreignKey: "cohortId" });

  // Clan 1-N Session
  Clan.hasMany(Session, { foreignKey: "clanId" });
  Session.belongsTo(Clan, { foreignKey: "clanId" });

  // Session 1-N AttendanceRecord
  Session.hasMany(AttendanceRecord, { foreignKey: "sessionId" });
  AttendanceRecord.belongsTo(Session, { foreignKey: "sessionId" });

  // Student 1-N AttendanceRecord
  Student.hasMany(AttendanceRecord, { foreignKey: "studentId" });
  AttendanceRecord.belongsTo(Student, { foreignKey: "studentId" });

  Student.belongsToMany(Cohort, {
    through: StudentCohort,
    foreignKey: "studentId",
  });
  Cohort.belongsToMany(Student, {
    through: StudentCohort,
    foreignKey: "cohortId",
  });
}

export {
  sequelize,
  User,
  Campus,
  Cohort,
  Clan,
  Course,
  Group,
  Student,
  Session,
  AttendanceRecord,
  AttendanceConfig,
  StudentCohort,
};
