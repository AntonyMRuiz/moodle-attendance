import { DataTypes, Model } from 'sequelize';

export class Campus extends Model {}

export function initCampus(sequelize) {
  Campus.init(
    {
      id: { type: DataTypes.BIGINT, autoIncrement: true, primaryKey: true },
      name: { type: DataTypes.STRING(100), allowNull: false },
      code: { type: DataTypes.STRING(50), allowNull: false, unique: true }
    },
    {
      sequelize,
      modelName: 'Campus',
      tableName: 'campuses',
      timestamps: false
    }
  );
}
