import { DataTypes, Model } from 'sequelize';

export class Course extends Model {}

export function initCourse(sequelize) {
  Course.init(
    {
      id: { type: DataTypes.BIGINT, autoIncrement: true, primaryKey: true },
      moodleCourseId: { type: DataTypes.BIGINT, allowNull: false, unique: true },
      fullname: { type: DataTypes.STRING(255) },
      shortname: { type: DataTypes.STRING(100) }
    },
    {
      sequelize,
      modelName: 'Course',
      tableName: 'courses',
      timestamps: false
    }
  );
}
