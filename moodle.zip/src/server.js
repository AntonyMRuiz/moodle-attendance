import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';

import { env } from './config/env.js';
import { sequelize } from './config/db.js';
import { initModels } from './models/index.js';

import { authRouter } from './routes/authRoutes.js';
import { syncRouter } from './routes/syncRoutes.js';
import { reportRouter } from './routes/reportRoutes.js';
import { metaRouter } from './routes/metaRoutes.js';
import { statsRouter } from './routes/statsRoutes.js';

const app = express();

// Para __dirname en ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Middlewares
app.use(cors());
app.use(express.json());

// Rutas API
app.use('/auth', authRouter);
app.use('/sync', syncRouter);
app.use('/reports', reportRouter);
app.use('/meta', metaRouter);
app.use('/stats', statsRouter);

// Frontend estático (dashboard)
app.use(express.static(path.join(__dirname, '../public')));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'login.html'));
});

async function start() {
  try {
    initModels();
    await sequelize.authenticate();
    await sequelize.sync(); // puedes usar { alter: true } en desarrollo

    app.listen(env.port, () => {
      console.log(`Servidor corriendo en http://localhost:${env.port}`);
    });
  } catch (err) {
    console.error('Error iniciando servidor:', err);
    process.exit(1);
  }
}

start();
