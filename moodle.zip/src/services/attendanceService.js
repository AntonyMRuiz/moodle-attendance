import { env } from "../config/env.js";
import axios from "axios";
import { sequelize } from "../config/db.js";
import {
  AttendanceConfig,
  Session,
  AttendanceRecord,
  Student,
} from "../models/index.js";

async function getSessionsFromMoodle(attendanceId) {
  const params = {
    wstoken: env.moodleToken,
    moodlewsrestformat: env.moodleFormat,
    wsfunction: "mod_attendance_get_sessions",
    attendanceid: attendanceId,
  };

  const { data } = await axios.get(env.moodleBaseUrl, { params });

  if (Array.isArray(data)) return data;
  if (Array.isArray(data.sessions)) return data.sessions;
  return [];
}

/**
 * Sincroniza una sola configuración de asistencia (una fila de attendance_configs)
 */
export async function syncAttendanceForConfig(config) {
  const sessionsData = await getSessionsFromMoodle(config.moodleAttendanceId);

  await sequelize.transaction(async (t) => {
    for (const s of sessionsData) {
      // Filtrar por groupid si esta config está asociada a un grupo específico
      if (
        config.moodleGroupId > 0 &&
        s.groupid &&
        s.groupid !== config.moodleGroupId
      ) {
        continue;
      }

      const sessdate = new Date(s.sessdate * 1000);
      const moodleUrl = `${env.moodleTakeBase}&sessionid=${s.id}&grouptype=${
        s.groupid || 0
      }`;

      // Mapas de estados y usuarios
      const statusById = {};
      (s.statuses || []).forEach((st) => {
        statusById[st.id] = st;
      });

      const userById = {};
      (s.users || []).forEach((u) => {
        userById[u.id] = u;
      });

      // Resumen de asistencia
      let presentCount = 0;
      let lateCount = 0;
      let justifiedCount = 0;
      let unjustifiedCount = 0;

      (s.attendance_log || []).forEach((log) => {
        const st = statusById[Number(log.statusid)];
        const acronym = st?.acronym;

        if (acronym === "P") presentCount++;
        else if (acronym === "R") lateCount++;
        else if (acronym === "FJ") justifiedCount++;
        else if (acronym === "FI") unjustifiedCount++;
      });

      const totalStudents = (s.users || []).length;

      // Crear/actualizar sesión
      const [session] = await Session.upsert(
        {
          moodleSessionId: s.id,
          attendanceid: s.attendanceid,
          courseId: s.courseid || config.moodleCourseId || null,
          groupId: s.groupid || config.moodleGroupId || 0,

          attendanceConfigId: config.id,
          cohortId: config.cohortId,
          clanId: config.clanId,

          sessdate,
          description: s.description || null,
          duration: s.duration || 0,
          moodleUrl,

          totalStudents,
          presentCount,
          lateCount,
          justifiedCount,
          unjustifiedCount,
        },
        { transaction: t }
      );

      const sessionId =
        session.id ||
        (
          await Session.findOne({
            where: { moodleSessionId: s.id },
            transaction: t,
          })
        ).id;

      // Estudiantes
      for (const u of s.users || []) {
        const fullname = `${u.firstname} ${u.lastname}`.trim();
        await Student.upsert(
          {
            moodleUserId: u.id,
            firstname: u.firstname,
            lastname: u.lastname,
            fullname,
          },
          { transaction: t }
        );
      }

      await StudentCohort.findOrCreate({
        where: { studentId: student.id, cohortId: config.cohortId },
        defaults: { studentId: student.id, cohortId: config.cohortId },
        transaction: t,
      });

      // Borrar registros de asistencia anteriores de esa sesión
      await AttendanceRecord.destroy({
        where: { sessionId },
        transaction: t,
      });

      // Insertar registros de asistencia detallados
      for (const log of s.attendance_log || []) {
        const studentId = Number(log.studentid);
        const st = statusById[Number(log.statusid)] || {};
        await AttendanceRecord.create(
          {
            sessionId,
            studentId,
            statusAcronym: st.acronym || "UNK",
            statusDescription: st.description || null,
            statusGrade: st.grade ?? null,
            remarks: log.remarks || null,
          },
          { transaction: t }
        );
      }
    }
  });
}

/**
 * Sincroniza TODAS las configs activas
 */
export async function syncAllAttendanceConfigs() {
  const configs = await AttendanceConfig.findAll({
    where: { enabled: true },
  });

  for (const cfg of configs) {
    await syncAttendanceForConfig(cfg);
  }
}
