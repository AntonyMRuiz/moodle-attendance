import axios from 'axios';
import { env } from '../config/env.js';

export async function getSessionsFromMoodle(attendanceId) {
  const params = {
    wstoken: env.moodleToken,
    moodlewsrestformat: env.moodleFormat,
    wsfunction: 'mod_attendance_get_sessions',
    attendanceid: attendanceId
  };

  const { data } = await axios.get(env.moodleBaseUrl, { params });

  // Tu JSON era un objeto dentro de un array, aquí soportamos ambas formas
  if (Array.isArray(data)) return data;
  if (Array.isArray(data.sessions)) return data.sessions;
  return [];
}
